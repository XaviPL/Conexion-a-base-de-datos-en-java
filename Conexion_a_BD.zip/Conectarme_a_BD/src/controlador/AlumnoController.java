/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import modelo.Alumno;
import modelo.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Xavi
 */
public class AlumnoController {
    /*Conexion conectar = new Conexion();
    Connection miConexion = conectar.conexion();*/
   public AlumnoController(){
       
   }
   public Alumno buscarAlumno(int id){
       
       Alumno al = new Alumno();
       
       Conexion conectar = new Conexion();
       Connection cn = conectar.conexion();
       
       String sql = "SELECT * FROM tbl_alumnos WHERE alu_id=?";
       
       try {
           PreparedStatement pst = cn.prepareStatement(sql);
           pst.setInt(1, id);
           
           ResultSet rs= pst.executeQuery();
           while (rs.next()){
                
                al.setAlu_id(rs.getInt("alu_id"));
                al.setAlu_nom(rs.getString("alu_nom"));
                al.setAlu_cognom1(rs.getString("alu_cognom1"));
                al.setAlu_cognom2(rs.getString("alu_cognom2"));
                al.setAlu_correo(rs.getString("alu_correo"));
                
            }  
       } catch (SQLException ex) {
           //Logger.getLogger(AlumnoController.class.getName()).log(Level.SEVERE, null, ex);
       } finally {
           return al;
       }
   }
   
   //recuperar los datos del resulset y guardarlo en el arraylist
   public ArrayList<Alumno> mostrarAlumno (){
       ArrayList<Alumno> listaAlumno = new ArrayList<Alumno>();
       //pasos en una conexion
       //1 conectarme
       Conexion conectar = new Conexion();
       Connection cn = conectar.conexion();
       
       String sql = "SELECT * FROM tbl_alumnos";
       
       try {
           //2 crear estatement de la conexion de la bd
            Statement st = cn.createStatement();
            //3 lanzo la conexion
            ResultSet rs = st.executeQuery(sql);
            //4 lanza la consulta con el executeQuery
            while (rs.next()){
                //5 recorrer el resulset de tipo array
                Alumno al = new Alumno();
                al.setAlu_id(rs.getInt("alu_id"));
                al.setAlu_nom(rs.getString("alu_nom"));
                al.setAlu_cognom1(rs.getString("alu_cognom1"));
                al.setAlu_cognom2(rs.getString("alu_cognom2"));
                al.setAlu_correo(rs.getString("alu_correo"));
                listaAlumno.add(al);
                
            }  
       } catch (SQLException e){
           
       } finally {
       } try {
           cn.close();
       } catch (SQLException e){
           JOptionPane.showMessageDialog(null,"Conexion fallida, cerrar!");
       }
       return listaAlumno;
   }
   public void insertarAlumno(Alumno al) {
        //1 conectarme
       Conexion conectar = new Conexion();
       Connection cn = conectar.conexion();
       
       String sql = "INSERT INTO tbl_alumnos (alu_nom, alu_cognom1, alu_cognom2, alu_correo) VALUES (?, ?, ?, ?)";
       //String sql = "INSERT INTO tbl_alumnos (alu_nom, alu_cognom1, cognom2, alu_correo) VALUES ('alumno1', 'apellido1', 'apellido2', 'alumno@mail.mail')";
       
       try {
           //creamos el PreparedStatement para pasar parametros a mi consulta que son los interrogantes
           PreparedStatement pst = cn.prepareStatement(sql);
           //montamos una tabla para insertar datos en la bd
           pst.setString(1, al.getAlu_nom()); //el 1 es el primer interrogante (dato) de la consulta , el 2 el segundo y asi...
           pst.setString(2, al.getAlu_cognom1());
           pst.setString(3, al.getAlu_cognom2());
           pst.setString(4, al.getAlu_correo());
           //ejecutamos la consulta del pst
           //pst.executeUpdate();
           //variable para comprobar que hace la conexion, ya que pst devuelve 0 o 1
           int n=pst.executeUpdate();
           //
           if (n!=0){
               JOptionPane.showMessageDialog(null,"Se han insertado los datos correctamaente");
           }else {
               JOptionPane.showMessageDialog(null,"MO se han insertado los datos correctamaente");
           }
           //JOptionPane.showMessageDialog(null,"MO se han insertado los datos correctamaente");
       } catch (SQLException ex) {
           System.out.println(ex);
           JOptionPane.showMessageDialog(null,"La base de datos no esta operativa");
       }
       
   }
   public void modificarAlumno(Alumno al){
       String sql = "UPDATE tbl_alumnos SET alu_nom=?, alu_cognom1=?, alu_cognom2=?, alu_correo=? WHERE alu_id=?";
        //1 conectarme
       Conexion conectar = new Conexion();
       Connection cn = conectar.conexion();
       PreparedStatement pst;
       try {
           pst = cn.prepareStatement(sql);
           pst.setString(1, al.getAlu_nom()); //el 1 es el primer interrogante (dato) de la consulta , el 2 el segundo y asi...
           pst.setString(2, al.getAlu_cognom1());
           pst.setString(3, al.getAlu_cognom2());
           pst.setString(4, al.getAlu_correo());
           pst.setInt(5, al.getAlu_id());
       } catch (SQLException ex) {
           
       }
       
   }
   public void eliminarAlumno(int id) {
      String sql = "DELETE FROM tbl_alumnos WHERE alu_id=?";
        //1 conectarme
       Conexion conectar = new Conexion();
       Connection cn = conectar.conexion();
       PreparedStatement pst;
       try {
           pst = cn.prepareStatement(sql);
           pst.setInt(1, id);
           int n = pst.executeUpdate();
           if (n != 0){
               JOptionPane.showMessageDialog(null,"Se ha borrado el usuario correctamaente");
           } else {
               JOptionPane.showMessageDialog(null,"El usuario no se ha insertado correctamaente");
           }
       } catch (SQLException ex) {
           
       } 
   }
}




//pasos para hacer la conexion:
//1. driver manager
//2. establecer conexion
//3. ejecutar sentencia sql con un onjeto del tipo STATEMENT
//4. 