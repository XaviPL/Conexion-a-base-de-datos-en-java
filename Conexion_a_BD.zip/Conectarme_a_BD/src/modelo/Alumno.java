/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Xavi
 */
public class Alumno {
    //atributos
    private int alu_id;
    private String alu_nom;
    private String alu_cognom1;
    private String alu_cognom2;
    private String alu_correo;
    
    //constructor
    public Alumno(){
        
    }

    public Alumno(int alu_id, String alu_nom, String alu_cognom1, String alu_cognom2, String alu_correo) {
        this.alu_id = alu_id;
        this.alu_nom = alu_nom;
        this.alu_cognom1 = alu_cognom1;
        this.alu_cognom2 = alu_cognom2;
        this.alu_correo = alu_correo;
    }
    
    public Alumno( String alu_nom, String alu_cognom1, String alu_cognom2, String alu_correo) {
        //this.alu_id = alu_id;
        this.alu_nom = alu_nom;
        this.alu_cognom1 = alu_cognom1;
        this.alu_cognom2 = alu_cognom2;
        this.alu_correo = alu_correo;
    }
    
    //getters y setters

    public int getAlu_id() {
        return alu_id;
    }

    public void setAlu_id(int alu_id) {
        this.alu_id = alu_id;
    }

    public String getAlu_nom() {
        return alu_nom;
    }

    public void setAlu_nom(String alu_nom) {
        this.alu_nom = alu_nom;
    }

    public String getAlu_cognom1() {
        return alu_cognom1;
    }

    public void setAlu_cognom1(String alu_cognom1) {
        this.alu_cognom1 = alu_cognom1;
    }

    public String getAlu_cognom2() {
        return alu_cognom2;
    }

    public void setAlu_cognom2(String alu_cognom2) {
        this.alu_cognom2 = alu_cognom2;
    }

    public String getAlu_correo() {
        return alu_correo;
    }

    public void setAlu_correo(String alu_correo) {
        this.alu_correo = alu_correo;
    }
    
    
}
