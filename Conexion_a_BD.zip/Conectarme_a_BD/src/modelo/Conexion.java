/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Xavi
 */
public class Conexion {
    // Datos de la conexion
    public String db = "bd_alumnos";
    public String url = "jdbc:mysql://localhost:3306/"+db; //el puerto por defecto es el 3306 no es necesario poner localhost o la ip si no si tenemos que poner localhost
    public String user = "root";
    public String password = "";
    
    //1-establecer conexion
    //funcion que conecta la base de datos y java
    public Connection conexion(){
       //indicamos la ruta donde esta mi driver
        Connection conectar = null;
       try {
          Class.forName("org.gjt.mm.mysql.Driver");//indicamos donde esta el driver, no hace falta poner el .class
          conectar = DriverManager.getConnection(url, user, password);
          System.out.println("Conexion establecida con exito");
       } catch (ClassNotFoundException | SQLException e) {
           System.out.println("Error de conexion");
           System.out.println(e);
       } finally {
        return conectar; 
       }
    }
 
    //creamos el constructor
    public Conexion(){
}
}
